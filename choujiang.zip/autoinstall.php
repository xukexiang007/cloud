<?php
/**
 * Created by PhpStorm.
 * User: kuake
 * Date: 2019/8/15
 * 微站网-让建站变得更简单
 *
 * 安装包集成规范：
==============================
程序安装驱动：autoinstall.php
程序资源包：source.zip
==============================
注意点：
1：安装后务必删除 source.zip 
2：如果source.zip不存在 则不执行安装
3：检查程序的自带的install 防止程序自带的安装
================================
阿拉丁建站系统宝塔版(微站) 安装原理：
宝塔初始主机生成网站安装驱动
			↓
网站安装驱动下载程序安装驱动/程序资源包
			↓
程序安装驱动对程序资源包进行操作
================================
微站网:www.w-cms.cn
 */
$wcmsuser=$_GET['user'];
$wcmspass=$_GET['pass'];


$ml = './';

$zip=new ZipArchive();
      if($zip->open('source.zip')===true){

        //安装时先将目录下的其他文件删除
       $path = "./";
       $arr=array("./autosite.php","./autoinstall.php","./index.html","./source.zip");
       deldir($path,$arr);


       $zip->extractTo($ml);
       $zip->close();
       chmod($ml.'source.zip',0777);
       chmod($ml.'index.php',0777);
       chmod($ml.'config.php',0777);
		   chmod($ml.'install.sql',0777);



	      $conn = file_get_contents($ml.'/config.inc.php');
	      $conn = str_replace('wcmsuser',$wcmsuser,$conn);
	      $conn = str_replace('wcmsuser',$wcmsuser,$conn);
	      $conn = str_replace('wcmspass',$wcmspass,$conn);
	      file_put_contents($ml.'/config.inc.php',$conn);




          mysql_connect('localhost',$wcmsuser,$wcmspass); //连接本地数据库
          mysql_select_db($wcmsuser);
          mysql_query("set names 'utf8'");

          $result = mysql_query("SHOW TABLES"); //
          while ($row = mysql_fetch_row($result)) {
              mysql_query("DROP TABLE `{$row[0]}`");
          }
		  
          $Sqls = file_get_contents($ml.'/install.sql'); //将数据库文件导入数据库
          $SqlArr = explode(';', $Sqls);
          foreach ( $SqlArr as $sql ) {
            if(mysql_query( $sql )===false){
                echo mysql_error();
               }
          }

          unlink($ml.'/source.zip'); //删除source.zip资源包
          echo json_encode(array('code'=>'1','msg'=>'搭建完成'));
		  exit;
      }else{
		  echo json_encode(array('code'=>'-1','msg'=>'不存在资源包'));
		  exit;
	  }

//重装时遍历删除文件
     function deldir($path,$arr=null){
         if(is_dir($path)){
             
            $p = scandir($path);
           
            foreach($p as $val){
                if($val !="." && $val !=".."){
                    if(is_dir($path.$val)){
                        deldir($path.$val.'/');
                        @rmdir($path.$val.'/');
                    }else{
                      if(!in_array($path.$val,$arr)){
                        unlink($path.$val);
                      }
                    }
                }
            }
        }
     }
    

?>
